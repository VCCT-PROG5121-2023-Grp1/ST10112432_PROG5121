/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.poe;

/**
 *
 * @author Kanya Mkoka
 * Student Number: ST10112432
 * Group: 4
 * POE Part 2
 */
import javax.swing.*;
public class taskApplication 
{
    private static int taskCount = 0;
    static String taskStatus = " ";
    static int taskTotalTime;
    
    public void addTask()
    {
        int taskNum = Integer.parseInt(JOptionPane.showInputDialog("Please indicate the number of tasks you want to include: "));
        for (int i = 1; i <= taskNum; i++);
        {
            String taskName = JOptionPane.showInputDialog("Please enter the task's name here: " + taskNum );
            JOptionPane.showMessageDialog(null, "The newly added task's name is: " + taskName);
            
            String description = " ";
            while (description.isEmpty() || description.length() > 50)
            {
                description = JOptionPane.showInputDialog("Please describe your task, ensure that it is less that 50 characters: ");
                JOptionPane.showMessageDialog(null, "Interpretation of Task has been successfully added: " + description);
                
                if (description.length() > 50)
                {
                    JOptionPane.showMessageDialog(null, "Please interpret task in less than 50 characters");
                }
            }
                       
            String developerFirstName = JOptionPane.showInputDialog("Please enter the first name of the developer: ");
            String developerLastName = JOptionPane.showInputDialog("Please enter the last name of the developer: ");
            JOptionPane.showMessageDialog(null, "The developer that has been assigned to the task is: " + developerFirstName + " " + developerLastName);
            
            String taskDurationStng = JOptionPane.showInputDialog("Please enter the estimated duration of the task in hours: ");
            int taskDuration = Integer.parseInt(taskDurationStng);
            JOptionPane.showMessageDialog(null, "The estimated time to complete task : " + taskName + "is: " + taskDuration + "hours");
            
            String firstLetters2 = taskName.substring(0, 2).toUpperCase();
            String lastLetters3 = developerLastName.substring(developerLastName.length() - 3).toUpperCase();
            
            String taskID = firstLetters2 + " : " + taskCount + " : " + lastLetters3;
            JOptionPane.showMessageDialog(null, "The task ID is: " + taskID);
            taskCount++;
            
            String[] status = {"To do", "Doing", "Done"};
            int selection = JOptionPane.showOptionDialog(null, "Please select your task status: ", "Task Status", 0, 3, null, status, status[0]);
            
            if (selection == 0)
            {
                taskStatus = "To do";
                JOptionPane.showMessageDialog(null, "The task to do is: " + taskStatus);
            }
            if (selection == 1)
            {
                taskStatus = "Doing";
                JOptionPane.showMessageDialog(null, "The task currently being done is:" + taskStatus);
            }
            if (selection == 2)
            {
                taskStatus = "Done";
                JOptionPane.showMessageDialog(null, "This task has been completed" + taskStatus);
            }
            JOptionPane.showMessageDialog(null, "Task Status: " + taskStatus + "\nDeveloper details: " + developerFirstName + " " + developerLastName + "\nTask number: " + taskNum + "\nTask name: " + taskName + "\nTask Description: " + description + "\nTask Identification: " + taskID + "\nTask Duration: " + taskDuration); 
        }
        //taskTotalTime = taskTotalTime + taskDuration;
        JOptionPane.showMessageDialog(null, "The total time for all the tasks is: " + taskTotalTime);
    }
    public void showReport()
    {
        JOptionPane.showMessageDialog(null, "Coming Soon: ");
    }
}
