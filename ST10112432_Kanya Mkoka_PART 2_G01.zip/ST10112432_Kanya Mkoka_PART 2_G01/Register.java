/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poe;

/**
 *
 * @author Kay Mkoka
 * Student Number: ST10112432
 * Group: 4
 * POE Part 1 and 2
 */
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Register
{

    private static Object scanner;
  
    static 
    {
      Register();
      Register Register = new Register();
      //Login();
    }
    static
    {
        Login Login;
        
        Login = new Login();
    }
      public static void Register()
      {
          boolean run = true;
          while (run) 
          {
              System.out.println("Enter 1 to Register, 2 to Login or 3 to Exit");
              
              Scanner scn = new Scanner(System.in); //declaring a new scanner
              Login Log = new Login();
        //      Log.checkpasswordComplexity ();
              int choice = scn.nextInt();
              switch (choice)
              {
                  case 1:
                      Register();
                      break;
              }
              switch (choice)
              {
                  case 2:
//                    Log.Login();
                    break;
              }
              switch (choice)
              {
                  case 3:
            //        Exit();
                    break;
              }
          }
      }
}