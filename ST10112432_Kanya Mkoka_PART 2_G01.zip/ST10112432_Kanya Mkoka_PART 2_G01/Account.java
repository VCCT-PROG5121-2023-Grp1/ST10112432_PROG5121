/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poe;

/**
 *
 * @author Kanya Mkoka
 * Student Number: ST10112432
 * Group: 4
 * POE Part 1 and 2
 */
import java.util.Scanner; //importing the scanner method
import javax.swing.*; //importing the JOptionPane method
public class Account 
{
   
    static String username;
    static String password;
    static String firstName;
    static String lastName;
   
    private static int PasswordLength = 8;
    private static String SpecialChar = "!@#$%^&*()_?";
    private static boolean valid;
    private Scanner scn;
    
    
    
    public void username()
    {
        username = JOptionPane.showInputDialog(null,"Please enter your username");
        validuserName(username);
    }
    
    public void validuserName(String name)
    {
        boolean underscore = false;
        
        if (name.contains("_"))
        {
          underscore = true;
        }
        if (name.length() <=5 && underscore == true)
        {
            JOptionPane.showMessageDialog(null, "UserName sucessfully captured");
        }
            else
            {
                JOptionPane.showMessageDialog(null, "UserName is not correctly formated");
            }
    }
    
    //implementing getters & setters
    public Scanner getScn(Scanner scn) 
    {
        return scn;
    }

    public void setScn(Scanner scn) 
    {
        this.scn = scn;
    }

    public static String getUsername() 
    {
        return username;
    }

    public static void setUsername(String Username) 
    {
        Account.username = Username;
    }

    public static String getPassword() 
    {
        return password;
    }

    public static void setPassword(String Password) 
    {
        Account.password = Password;
    }

    public static int getPasswordLength() 
    {
        return PasswordLength;
    }

    public static void setPasswordLength(int PasswordLength) 
    {
        Account.PasswordLength = PasswordLength;
    }

    public static String getSpecialChar() 
    {
        return SpecialChar;
    }

    public static void setSpecialChar(String SpecialChar) 
    {
        Account.SpecialChar = SpecialChar;
    }

    public static boolean isValid() 
    {
        return valid;
    }

    public static void setValid(boolean valid) 
    {
        Account.valid = valid;
    }
    
}
