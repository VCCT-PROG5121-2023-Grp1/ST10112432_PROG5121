/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.poe;

/**
 *
 * @author Kanya Mkoka
 * Student Number: ST10112432
 * Group: 4
 * POE Part 2
 */
import javax.swing.*;
public class easyKanban
       
{
    taskApplication t = new taskApplication();
    
    public void easyKanban()
    {
        JOptionPane.showMessageDialog(null, "Welcome to Easy Kanban");
       
        String[] selection = {"Add Tasks", "Show Report", "Quit"};
        
        JOptionPane.showOptionDialog(null, "Please choose an option: ", "Easy Kanban Dropdown", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, selection, selection [0]);
        
        int choice = 0;
        
        switch (choice)
        {
            case 0:
                t.addTask();
                break;
            case 1:
                t.showReport();
            case 2:
                JOptionPane.showMessageDialog(null, "Exiting Easy Kanban. See you next time!");
            default :
                JOptionPane.showMessageDialog(null, "Incorrect details. Please try again");
        }
    }
}
