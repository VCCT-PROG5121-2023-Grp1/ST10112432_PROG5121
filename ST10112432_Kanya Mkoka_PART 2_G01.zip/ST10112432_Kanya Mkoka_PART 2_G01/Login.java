/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.poe;




/**
 *
 * @author Kanya Mkoka
 * Student Number: ST10112432
 * Group: 4
 * POE Part 1 and 2
 */
import javax.swing.JOptionPane;
public class Login        
{
    static String logUsername;
    static String logPassword;
    static Account[] accList;
    static String SpecialChar = "!@#$%^&*()_?";
    public Login()
    {//creating an arrayed list for accounts
        accList = new Account[5];
        accList[0] = new Account();
        accList[1] = new Account();
        accList[2] = new Account();
        accList[3] = new Account();
        accList[4] = new Account();
    }
    
    static boolean checkusername(String username)
    {
         
        boolean underScore = false;
        //if the usename meets the requirements thus containing an underscore
        if (username.contains("_"))
        {
            underScore = true;
        }
        if (username.length() <=5 && username.contains("_"))
        {
            //Username meets requirements
            JOptionPane.showMessageDialog(null, "Username has been sucessfully captured");   
        }
            else
            {
                //Username does not meet requirements
                JOptionPane.showMessageDialog(null, "Invalid username format. Please try again");
            }
            return false; //please try again
    }
    
    public boolean checkpasswordComplexity ()
    {
        boolean userPassword = false;
        return false; 
    }
    public static boolean PasswordLength(String Password)
    {
        boolean valid = false;
        if(Password.length() <= 8)
        {
            valid = true; 
        }
        return valid;
    }
    public static boolean PasswordUppercase(String Password, boolean valid)
    {
        for(int i=0; i<Password.length(); i++)
        {
            if(Character.isUpperCase(Password.charAt(i)))
            valid = true; 
        }
        return valid;
    }
   public static boolean PasswordDigit(String Password) 
   {
       boolean valid = false;
       for(int i = 0; i<Password.length(); i++)
        {
            if(Character.isDigit(Password.charAt(i)))
            valid = true; 
        }
        return valid;
   }
   
    public static boolean PasswordCharacter(String Password) 
   {
       boolean valid = false;
       for(int i=0; i<SpecialChar.length(); i++)
        {
            if(Character.isDigit(Password.charAt(i)))
            valid = true;
            break;
        }
       return valid;
    }
   
   public void registerUser()
   {
       String username = "kanya";
       if (checkpasswordComplexity() == true && checkusername(username)== true)
       {
        JOptionPane.showMessageDialog(null, "Registration Success!");
       }
          else
            {
                JOptionPane.showMessageDialog(null, "Registration failed. Please try again");
            }
   }
        
}