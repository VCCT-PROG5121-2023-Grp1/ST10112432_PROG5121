/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.poe;

/**
 *
 * @author Kanya Mkoka
 * Student Number: ST10112432
 * Group: 4
 * POE Part 2
 */
import javax.swing.*;
public class task 
{
  private String taskID;
  private String taskDescription;
  int hours;
  int totalHours;
  static task[] taskList;
  
  
  public task(String taskDescription, int hours)
  {
      this.taskID = taskID;
      this.taskDescription = taskDescription;
      this.hours = hours;
      totalHours = hours;
      
  }
  
  public static boolean checktaskDescription (String taskDescription)
  {
       boolean description = false;
       return taskDescription.length() <=50;
  }
   
  private String createTaskID()
  {
      boolean ID = false;
      return taskID;
  }
  
  public String taskDetails()
  {
      return "taskID: " + taskID + "\n Task Description: " + taskDescription + "\n Hours" + hours;
  }
  
  public int totalHours()
  {
      return totalHours;   
  }  
}
