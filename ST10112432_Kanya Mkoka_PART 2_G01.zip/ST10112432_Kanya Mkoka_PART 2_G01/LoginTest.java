/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.poe;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Kay Mkoka
 */
public class LoginTest {
    
    public LoginTest() {
    }

    @org.junit.jupiter.api.BeforeAll
    public static void setUpClass() throws Exception {
    }

    @org.junit.jupiter.api.AfterAll
    public static void tearDownClass() throws Exception {
    }

    @org.junit.jupiter.api.BeforeEach
    public void setUp() throws Exception {
    }

    @org.junit.jupiter.api.AfterEach
    public void tearDown() throws Exception {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of checkusername method, of class Login.
     */
    @org.junit.jupiter.api.Test
    public void testCheckusername() {
        System.out.println("checkusername");
        String username = "";
        boolean expResult = false;
        boolean result = Login.checkusername(username);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkpasswordComplexity method, of class Login.
     */
    @org.junit.jupiter.api.Test
    public void testCheckpasswordComplexity() {
        System.out.println("checkpasswordComplexity");
        Login instance = new Login();
        boolean expResult = false;
        boolean result = instance.checkpasswordComplexity();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of PasswordLength method, of class Login.
     */
    @org.junit.jupiter.api.Test
    public void testPasswordLength() {
        System.out.println("PasswordLength");
        String Password = "";
        boolean expResult = false;
        boolean result = Login.PasswordLength(Password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of PasswordUppercase method, of class Login.
     */
    @org.junit.jupiter.api.Test
    public void testPasswordUppercase() {
        System.out.println("PasswordUppercase");
        String Password = "";
        boolean valid = false;
        boolean expResult = false;
        boolean result = Login.PasswordUppercase(Password, valid);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of PasswordDigit method, of class Login.
     */
    @org.junit.jupiter.api.Test
    public void testPasswordDigit() {
        System.out.println("PasswordDigit");
        String Password = "";
        boolean expResult = false;
        boolean result = Login.PasswordDigit(Password);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of registerUser method, of class Login.
     */
    @org.junit.jupiter.api.Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        Login instance = new Login();
        String expResult = "";
        String result = instance.registerUser();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of login method, of class Login.
     */
    @org.junit.jupiter.api.Test
    public void testLogin() {
        System.out.println("login");
        Login.login();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
