/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poe;

/**
 * @author Kanya Mkoka
 * Student Number: ST10112432
 * Group: 4
 * POE Part 1 and 2
 */
import java.util.Scanner; //importing Scanner method
import javax.swing.*; //importing the JOptionPane method
public class POE
{     
    Scanner scn = new Scanner(System.in);//declaring a new Scanner (System.in)
    
    //declaring all instance variables 
    private String username;
    private String password;
    private static String firstName;
    private static String lastName;
    private static final int PasswordLength = 8;
    private static String SpecialChar = "!@#$%^&*()_?";
    private String taskID;
    private String taskDescription;
    int totalHours;
    
    //start main method 
    public static void main(String[] args)
    {
        POE poe = new POE();
        poe.Reg();
    }
    
    //while (display)
     public void  Reg()
    {
        Account account = new Account (); 
        account.validuserName(username);
            
        firstName= JOptionPane.showInputDialog("Please enter your First Name");
        lastName= JOptionPane.showInputDialog("Please enter your Last Name");
        username = JOptionPane.showInputDialog("Please enter your username  ");
        password =JOptionPane.showInputDialog("Please enter your password"); 
    }
    
    static void Login() //login
    {
        String username = JOptionPane.showInputDialog("Please enter your username");
        String password = JOptionPane.showInputDialog("Please enter your password");
        
        JOptionPane.showMessageDialog(null, "Login Success!");
    }
    
   String taskDescription1 = JOptionPane.showInputDialog("Please enter TASK 1 description: ");
   int taskHours1 = Integer.parseInt(JOptionPane.showInputDialog("Enter task 1 hours:"));
   task task1 = new task(taskDescription1, taskHours1);

   String taskDescription2 = JOptionPane.showInputDialog("Enter task 2 description:");
   int taskHours2 = Integer.parseInt(JOptionPane.showInputDialog("Enter task 2 hours:"));
   task task2 = new task(taskDescription2, taskHours2);
   
   public int totalHours()
   {
       return totalHours;
   }
   
   String taskDetails = new String();
   
   //for (Task : task task)
   {
       JOptionPane.showMessageDialog(null, taskDetails.toString() + "Total Hours: " + totalHours());
   }
   
        
} //end of the part 1 
    

