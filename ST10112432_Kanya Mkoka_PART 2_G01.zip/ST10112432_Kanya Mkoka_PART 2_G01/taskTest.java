/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.poe;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Kay Mkoka
 */
public class taskTest {
    
    public taskTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of checktaskDescription method, of class task.
     */
    @org.junit.Test
    public void testChecktaskDescription() {
        System.out.println("checktaskDescription");
        String taskDescription = "";
        boolean expResult = false;
        boolean result = task.checktaskDescription(taskDescription);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of taskDetails method, of class task.
     */
    @org.junit.Test
    public void testTaskDetails() {
        System.out.println("taskDetails");
        task instance = null;
        String expResult = "";
        String result = instance.taskDetails();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of totalHours method, of class task.
     */
    @org.junit.Test
    public void testTotalHours() {
        System.out.println("totalHours");
        task instance = null;
        int expResult = 0;
        int result = instance.totalHours();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
